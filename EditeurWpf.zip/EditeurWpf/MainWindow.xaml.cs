﻿using Microsoft.Win32;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using Forms = System.Windows.Forms;

namespace EditeurWpf
{
    public partial class MainWindow : Window
    {
        private string currentFilePath = null;
        private bool isModified = false;

        public MainWindow()
        {
            InitializeComponent();
            Editor.TextChanged += Editor_TextChanged;
        }

        // --- Gestion modification
        private void Editor_TextChanged(object sender, TextChangedEventArgs e)
        {
            isModified = true;
            UpdateTitle();
        }

        private void UpdateTitle()
        {
            string fileName = currentFilePath ?? "Sans titre";
            this.Title = fileName + (isModified ? " *" : "") + " - Editeur WPF";
        }

        // --- Nouveau document
        private void NewFile_Click(object sender, RoutedEventArgs e)
        {
            if (!AskSaveIfNeeded()) return;
            Editor.Document.Blocks.Clear();
            currentFilePath = null;
            isModified = false;
            UpdateTitle();
        }

        // --- Ouvrir fichier
        private void OpenFile_Click(object sender, RoutedEventArgs e)
        {
            if (!AskSaveIfNeeded()) return;

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "RTF (*.rtf)|*.rtf|Texte (*.txt)|*.txt";

            if (dlg.ShowDialog() == true)
            {
                currentFilePath = dlg.FileName;
                Editor.Document.Blocks.Clear();

                using (FileStream fs = new FileStream(currentFilePath, FileMode.Open))
                {
                    if (currentFilePath.EndsWith(".rtf"))
                        new TextRange(Editor.Document.ContentStart, Editor.Document.ContentEnd).Load(fs, DataFormats.Rtf);
                    else
                        new TextRange(Editor.Document.ContentStart, Editor.Document.ContentEnd).Load(fs, DataFormats.Text);
                }

                isModified = false;
                UpdateTitle();
            }
        }

        // --- Enregistrer
        private void SaveFile_Click(object sender, RoutedEventArgs e)
        {
            if (currentFilePath == null) SaveAsFile_Click(sender, e);
            else SaveToFile(currentFilePath);
        }

        private void SaveAsFile_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Filter = "RTF (*.rtf)|*.rtf|Texte (*.txt)|*.txt";

            if (dlg.ShowDialog() == true)
            {
                currentFilePath = dlg.FileName;
                SaveToFile(currentFilePath);
            }
        }

        private void SaveToFile(string path)
        {
            TextRange range = new TextRange(Editor.Document.ContentStart, Editor.Document.ContentEnd);
            using (FileStream fs = new FileStream(path, FileMode.Create))
            {
                if (path.EndsWith(".rtf"))
                    range.Save(fs, DataFormats.Rtf);
                else
                    range.Save(fs, DataFormats.Text);
            }
            isModified = false;
            UpdateTitle();
        }

        // --- Demander enregistrement si modifié
        private bool AskSaveIfNeeded()
        {
            if (!isModified) return true;

            MessageBoxResult r = MessageBox.Show("Le document a été modifié. Voulez-vous enregistrer ?", "Confirmation", MessageBoxButton.YesNoCancel, MessageBoxImage.Warning);
            if (r == MessageBoxResult.Yes) { SaveFile_Click(null, null); return true; }
            else if (r == MessageBoxResult.No) return true;
            else return false;
        }

        // --- Formatage
        private void Bold_Click(object sender, RoutedEventArgs e) => EditingCommands.ToggleBold.Execute(null, Editor);
        private void Italic_Click(object sender, RoutedEventArgs e) => EditingCommands.ToggleItalic.Execute(null, Editor);
        private void Underline_Click(object sender, RoutedEventArgs e) => EditingCommands.ToggleUnderline.Execute(null, Editor);

        private void AlignLeft_Click(object sender, RoutedEventArgs e) => EditingCommands.AlignLeft.Execute(null, Editor);
        private void AlignCenter_Click(object sender, RoutedEventArgs e) => EditingCommands.AlignCenter.Execute(null, Editor);
        private void AlignRight_Click(object sender, RoutedEventArgs e) => EditingCommands.AlignRight.Execute(null, Editor);

        private void Color_Click(object sender, RoutedEventArgs e)
        {
            Forms.ColorDialog dlg = new Forms.ColorDialog();
            if (dlg.ShowDialog() == Forms.DialogResult.OK)
            {
                var brush = new SolidColorBrush(Color.FromArgb(dlg.Color.A, dlg.Color.R, dlg.Color.G, dlg.Color.B));
                Editor.Selection.ApplyPropertyValue(TextElement.ForegroundProperty, brush);
            }
        }

        private void Font_Click(object sender, RoutedEventArgs e)
        {
            Forms.FontDialog dlg = new Forms.FontDialog();
            if (dlg.ShowDialog() == Forms.DialogResult.OK)
            {
                Editor.Selection.ApplyPropertyValue(TextElement.FontFamilyProperty, new FontFamily(dlg.Font.Name));
                Editor.Selection.ApplyPropertyValue(TextElement.FontSizeProperty, (double)dlg.Font.Size * 1.3);
            }
        }

        // --- Recherche / Remplacer
        private void Search_Click(object sender, RoutedEventArgs e)
        {
            string query = SearchBox.Text ?? "";
            if (string.IsNullOrEmpty(query)) return;

            TextPointer start = FindText(query);
            if (start != null)
            {
                TextPointer end = start.GetPositionAtOffset(query.Length);
                Editor.Selection.Select(start, end);
                Editor.Focus();
            }
            else MessageBox.Show("Texte non trouvé.");
        }

        private TextPointer FindText(string text)
        {
            TextRange document = new TextRange(Editor.Document.ContentStart, Editor.Document.ContentEnd);
            int index = document.Text.IndexOf(text, System.StringComparison.OrdinalIgnoreCase);
            if (index >= 0) return GetTextPositionAtOffset(Editor.Document.ContentStart, index);
            return null;
        }

        private TextPointer GetTextPositionAtOffset(TextPointer start, int offset)
        {
            TextPointer current = start; int cnt = 0;
            while (current != null)
            {
                if (current.GetPointerContext(LogicalDirection.Forward) == TextPointerContext.Text)
                {
                    string run = current.GetTextInRun(LogicalDirection.Forward);
                    if (offset <= cnt + run.Length) return current.GetPositionAtOffset(offset - cnt);
                    cnt += run.Length;
                }
                current = current.GetNextContextPosition(LogicalDirection.Forward);
            }
            return null;
        }

        private void Replace_Click(object sender, RoutedEventArgs e)
        {
            string search = SearchBox.Text ?? "";
            string replace = ReplaceBox.Text ?? "";
            if (string.IsNullOrEmpty(search)) return;

            TextRange document = new TextRange(Editor.Document.ContentStart, Editor.Document.ContentEnd);
            string content = document.Text.Replace(search, replace, System.StringComparison.OrdinalIgnoreCase);

            Editor.Document.Blocks.Clear();
            Editor.Document.Blocks.Add(new Paragraph(new Run(content)));
            isModified = true;
            UpdateTitle();
        }
    }
}
