﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Windows.Forms;

namespace MiniWinRAR
{
    public partial class Form1 : Form
    {
        private readonly ArchiveManager _archiveManager = new ArchiveManager();
        private string _currentFolder;
        private string _currentZip;

        private bool _darkTheme = false;
        private string _language = "FR";

        public Form1()
        {
            InitializeComponent();

            // Double-clic liste
            listViewFiles.DoubleClick += listViewFiles_DoubleClick;

            // Boutons ToolStrip
            btnUp.Click += btnUp_Click;
            btnAdd.Click += btnAdd_Click;
            btnExtract.Click += btnExtract_Click;
            btnTest.Click += btnTest_Click;
            btnDelete.Click += btnDelete_Click;
            btnSearch.Click += btnSearch_Click;
            btnInfo.Click += btnInfo_Click;
            btnRepair.Click += btnRepair_Click;

            // Menus
            nouveauToolStripMenuItem.Click += nouveauToolStripMenuItem_Click;
            ouvrirToolStripMenuItem.Click += ouvrirToolStripMenuItem_Click;
            quitterToolStripMenuItem.Click += quitterToolStripMenuItem_Click;

            extraireToolStripMenuItem.Click += extraireToolStripMenuItem_Click;
            ajouterToolStripMenuItem.Click += ajouterToolStripMenuItem_Click;
            testerToolStripMenuItem.Click += testerToolStripMenuItem_Click;

            reparerToolStripMenuItem.Click += reparerToolStripMenuItem_Click;
            convertirToolStripMenuItem.Click += convertirToolStripMenuItem_Click;

            langueToolStripMenuItem.Click += langueToolStripMenuItem_Click;
            themeToolStripMenuItem.Click += themeToolStripMenuItem_Click;
            parametresToolStripMenuItem.Click += parametresToolStripMenuItem_Click;

            aproposToolStripMenuItem.Click += aproposToolStripMenuItem_Click;
            licenceToolStripMenuItem.Click += licenceToolStripMenuItem_Click;

            // Dossier de départ : Bureau
            _currentFolder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            LoadFolder(_currentFolder);

            // Appliquer thème + langue par défaut
            ApplyTheme();
            ApplyLanguage();
        }

        // ============================
        // ===== EXPLORATEUR ==========
        // ============================

        private void LoadFolder(string path)
        {
            try
            {
                listViewFiles.Items.Clear();
                DirectoryInfo dir = new DirectoryInfo(path);

                foreach (var d in dir.GetDirectories())
                {
                    ListViewItem item = new ListViewItem(d.Name);
                    item.SubItems.Add("");
                    item.SubItems.Add("Dossier");
                    item.SubItems.Add(d.LastWriteTime.ToString("dd/MM/yyyy HH:mm"));
                    item.Tag = d.FullName;
                    listViewFiles.Items.Add(item);
                }

                foreach (var f in dir.GetFiles())
                {
                    ListViewItem item = new ListViewItem(f.Name);
                    item.SubItems.Add(FormatSize(f.Length));
                    item.SubItems.Add(f.Extension);
                    item.SubItems.Add(f.LastWriteTime.ToString("dd/MM/yyyy HH:mm"));
                    item.Tag = f.FullName;
                    listViewFiles.Items.Add(item);
                }

                statusLabel.Text =
                    $"{dir.GetDirectories().Length} dossier(s), {dir.GetFiles().Length} fichier(s)";

                Text = "Mini-WinRAR - " + path;
                _currentFolder = path;
                _currentZip = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur : " + ex.Message);
            }
        }

        private void LoadZip(string zipPath)
        {
            listViewFiles.Items.Clear();

            try
            {
                using (var zip = ZipFile.OpenRead(zipPath))
                {
                    foreach (var entry in zip.Entries)
                    {
                        // ignorer les "dossiers"
                        if (entry.FullName.EndsWith("/")) continue;

                        ListViewItem item = new ListViewItem(entry.FullName);
                        item.SubItems.Add(FormatSize(entry.Length));
                        item.SubItems.Add("Fichier dans archive");
                        item.SubItems.Add(entry.LastWriteTime.ToLocalTime().ToString("dd/MM/yyyy HH:mm"));
                        item.Tag = entry.FullName;
                        listViewFiles.Items.Add(item);
                    }

                    statusLabel.Text = $"{zip.Entries.Count} entrée(s) dans l'archive";
                }

                Text = "Mini-WinRAR - " + Path.GetFileName(zipPath);
                _currentZip = zipPath;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la lecture de l'archive : " + ex.Message);
            }
        }

        private void listViewFiles_DoubleClick(object sender, EventArgs e)
        {
            if (listViewFiles.SelectedItems.Count == 0)
                return;

            // Dans une archive : on extrait dans un temp puis on ouvre
            if (_currentZip != null)
            {
                string entryName = listViewFiles.SelectedItems[0].Tag?.ToString();
                if (string.IsNullOrEmpty(entryName))
                    return;

                try
                {
                    string tempFolder = Path.Combine(Path.GetTempPath(), "MiniWinRAR");
                    Directory.CreateDirectory(tempFolder);

                    string tempFilePath = Path.Combine(tempFolder, Path.GetFileName(entryName));

                    using (var zip = ZipFile.OpenRead(_currentZip))
                    {
                        var entry = zip.GetEntry(entryName);
                        if (entry == null)
                        {
                            MessageBox.Show("Entrée introuvable dans l'archive.");
                            return;
                        }

                        entry.ExtractToFile(tempFilePath, overwrite: true);
                    }

                    Process.Start(new ProcessStartInfo
                    {
                        FileName = tempFilePath,
                        UseShellExecute = true
                    });
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de l'ouverture du fichier : " + ex.Message);
                }

                return;
            }

            // Mode explorateur
            string path = listViewFiles.SelectedItems[0].Tag?.ToString();
            if (path == null) return;

            if (Directory.Exists(path))
            {
                LoadFolder(path);
            }
            else if (File.Exists(path))
            {
                string ext = Path.GetExtension(path).ToLowerInvariant();
                if (ext == ".zip" || ext == ".keyce")
                {
                    LoadZip(path);
                }
                else
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = path,
                        UseShellExecute = true
                    });
                }
            }
        }

        // Bouton "⬆ Dossier parent"
        private void btnUp_Click(object sender, EventArgs e)
        {
            // Si on est dans une archive → revenir au dossier de l'archive
            if (_currentZip != null)
            {
                string folder = Path.GetDirectoryName(_currentZip);
                if (!string.IsNullOrEmpty(folder) && Directory.Exists(folder))
                {
                    LoadFolder(folder);
                }
                return;
            }

            try
            {
                var parent = Directory.GetParent(_currentFolder);
                if (parent != null)
                {
                    LoadFolder(parent.FullName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Impossible de remonter : " + ex.Message);
            }
        }

        // ============================
        // ===== MENU FICHIER =========
        // ============================

        private void nouveauToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Création d'une archive vide : à implémenter si besoin.\n" +
                            "Actuellement, utilisez 'Ajouter' pour créer une archive à partir de fichiers.");
        }

        private void ouvrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Archives (.zip;.keyce)|.zip;.keyce|Tous les fichiers (.)|.";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                LoadZip(ofd.FileName);
            }
        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        // ============================
        // ===== MENU COMMANDES =======
        // ============================

        private void extraireToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnExtract_Click(sender, e);
        }

        private void ajouterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnAdd_Click(sender, e);
        }

        private void testerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnTest_Click(sender, e);
        }

        // ============================
        // ===== MENU OUTILS ==========
        // ============================

        private void reparerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnRepair_Click(sender, e);
        }

        private void convertirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_currentZip == null)
            {
                MessageBox.Show("Aucune archive ouverte.");
                return;
            }

            string ext = Path.GetExtension(_currentZip).ToLowerInvariant();
            string newExt = ext == ".zip" ? ".keyce" : ".zip";

            string newPath = Path.Combine(
                Path.GetDirectoryName(_currentZip) ?? "",
                Path.GetFileNameWithoutExtension(_currentZip) + newExt);

            try
            {
                File.Copy(_currentZip, newPath, overwrite: true);
                MessageBox.Show("Conversion terminée :\n" + newPath);
                LoadZip(newPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la conversion : " + ex.Message);
            }
        }

        // ============================
        // ===== MENU OPTIONS =========
        // ============================

        private void langueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _language = _language == "FR" ? "EN" : "FR";
            ApplyLanguage();
        }

        private void themeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _darkTheme = !_darkTheme;
            ApplyTheme();
        }

        private void parametresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string lang = _language == "FR" ? "Français" : "English";
            string theme = _darkTheme ? "Sombre / Dark" : "Clair / Light";

            MessageBox.Show(
                $"Langue actuelle : {lang}\nThème actuel : {theme}",
                _language == "FR" ? "Paramètres" : "Settings",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        // ============================
        // ===== MENU AIDE ============
        // ============================

        private void aproposToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mini-WinRAR\nVersion 1.0\nProjet scolaire.");
        }

        private void licenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Mini-WinRAR - Projet scolaire\n" +
                "Usage pédagogique uniquement, non destiné à un usage commercial.",
                "Licence",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        // ============================
        // ===== BOUTON AJOUTER =======
        // ============================

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // CAS 1 : on est dans une archive → on ajoute des fichiers classiques
            if (_currentZip != null)
            {
                using OpenFileDialog ofd = new OpenFileDialog();
                ofd.Multiselect = true;
                ofd.Filter = "Tous les fichiers (.)|.";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    _archiveManager.AddFiles(_currentZip, ofd.FileNames);
                    LoadZip(_currentZip);
                }
                return;
            }

            // CAS 2 : on est dans l'explorateur → on crée une NOUVELLE archive
            if (listViewFiles.SelectedItems.Count == 0)
            {
                MessageBox.Show("Sélectionnez au moins un fichier ou dossier dans la liste.");
                return;
            }

            var selectedPaths = new List<string>();

            foreach (ListViewItem item in listViewFiles.SelectedItems)
            {
                string path = item.Tag?.ToString();
                if (path == null) continue;

                if (File.Exists(path) || Directory.Exists(path))
                    selectedPaths.Add(path);
            }

            if (selectedPaths.Count == 0)
            {
                MessageBox.Show("Aucun élément valide sélectionné.");
                return;
            }

            string defaultName = Path.GetFileNameWithoutExtension(selectedPaths[0]);
            var dlg = new AddToArchiveForm(defaultName, _currentFolder);

            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                if (string.IsNullOrWhiteSpace(dlg.ArchiveName) ||
                    string.IsNullOrWhiteSpace(dlg.DestinationFolder))
                {
                    MessageBox.Show("Nom et emplacement obligatoires.");
                    return;
                }

                string archiveFullPath = Path.Combine(
                    dlg.DestinationFolder,
                    dlg.ArchiveName + dlg.SelectedExtension);

                try
                {
                    _archiveManager.CreateArchive(archiveFullPath, selectedPaths);
                    LoadZip(archiveFullPath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de la création de l'archive : " + ex.Message);
                }
            }
        }

        // ============================
        // ===== BOUTON EXTRAIRE ======
        // ============================

        private void btnExtract_Click(object sender, EventArgs e)
        {
            if (_currentZip == null)
            {
                MessageBox.Show("Aucune archive ouverte.");
                return;
            }

            using FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.Description = "Choisissez le dossier où extraire l'archive";

            if (fbd.ShowDialog() == DialogResult.OK)
            {
                try 
                {
                    _archiveManager.ExtractAll(_currentZip, fbd.SelectedPath);
                    MessageBox.Show("Extraction terminée.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de l'extraction : " + ex.Message);
                }
            }
        }

        // ============================
        // ===== BOUTON TESTER ========
        // ============================

        private void btnTest_Click(object sender, EventArgs e)
        {
            if (_currentZip == null)
            {
                MessageBox.Show("Aucune archive ouverte.");
                return;
            }

            bool ok = _archiveManager.TestArchive(_currentZip);

            if (ok)
                MessageBox.Show("Archive valide, aucune erreur détectée.");
            else
                MessageBox.Show("Archive corrompue ou illisible.");
        }

        // ============================
        // ===== BOUTON SUPPRIMER =====
        // ============================

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (_currentZip == null)
            {
                MessageBox.Show("La suppression fonctionne seulement à l'intérieur d'une archive ouverte.");
                return;
            }

            if (listViewFiles.SelectedItems.Count == 0)
            {
                MessageBox.Show("Sélectionnez au moins un fichier dans la liste.");
                return;
            }

            var names = new List<string>();

            foreach (ListViewItem item in listViewFiles.SelectedItems)
            {
                string nameInArchive = item.Tag?.ToString();
                if (!string.IsNullOrEmpty(nameInArchive))
                    names.Add(nameInArchive);
            }

            if (names.Count == 0)
            {
                MessageBox.Show("Impossible de déterminer les entrées à supprimer.");
                return;
            }

            if (MessageBox.Show("Supprimer les éléments sélectionnés de l'archive ?",
                                "Confirmation",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                try
                {
                    _archiveManager.RemoveEntries(_currentZip, names);
                    LoadZip(_currentZip);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de la suppression : " + ex.Message);
                }
            }
        }

        // ============================
        // ===== BOUTONS DIVERS =======
        // ============================

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string term = Prompt("Recherche", "Nom ou partie du nom du fichier à rechercher :");
            if (string.IsNullOrWhiteSpace(term))
                return;

            if (_currentZip == null)
                SearchInFolder(term);
            else
                SearchInArchive(term);
        }

        private void SearchInFolder(string term)
        {
            listViewFiles.Items.Clear();
            int count = 0;

            try
            {
                foreach (var file in Directory.EnumerateFiles(_currentFolder, "" + term + "", SearchOption.AllDirectories))
                {
                    FileInfo fi = new FileInfo(file);
                    ListViewItem item = new ListViewItem(fi.Name);
                    item.SubItems.Add(FormatSize(fi.Length));
                    item.SubItems.Add(fi.Extension);
                    item.SubItems.Add(fi.LastWriteTime.ToString("dd/MM/yyyy HH:mm"));
                    item.Tag = fi.FullName;
                    listViewFiles.Items.Add(item);
                    count++;
                }

                statusLabel.Text = $"Résultats de la recherche \"{term}\" : {count} fichier(s)";
                Text = "Mini-WinRAR - Recherche";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la recherche : " + ex.Message);
            }
        }

        private void SearchInArchive(string term)
        {
            listViewFiles.Items.Clear();
            int count = 0;

            try
            {
                using (var zip = ZipFile.OpenRead(_currentZip))
                {
                    foreach (var entry in zip.Entries)
                    {
                        if (entry.FullName.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            ListViewItem item = new ListViewItem(entry.FullName);
                            item.SubItems.Add(FormatSize(entry.Length));
                            item.SubItems.Add("Fichier dans archive");
                            item.SubItems.Add(entry.LastWriteTime.ToLocalTime().ToString("dd/MM/yyyy HH:mm"));
                            item.Tag = entry.FullName;
                            listViewFiles.Items.Add(item);
                            count++;
                        }
                    }
                }

                statusLabel.Text = $"Résultats dans l'archive pour \"{term}\" : {count} fichier(s)";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur de recherche dans l'archive : " + ex.Message);
            }
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            if (listViewFiles.SelectedItems.Count == 0)
            {
                MessageBox.Show("Sélectionnez un fichier ou un dossier.");
                return;
            }

            var item = listViewFiles.SelectedItems[0];

            if (_currentZip == null)
            {
                string path = item.Tag?.ToString();
                if (string.IsNullOrEmpty(path))
                    return;

                if (Directory.Exists(path))
                {
                    var dir = new DirectoryInfo(path);
                    MessageBox.Show(
                        $"Nom : {dir.Name}\n" +
                        $"Type : Dossier\n" +
                        $"Chemin : {dir.FullName}\n" +
                        $"Modifié : {dir.LastWriteTime:dd/MM/yyyy HH:mm}",
                        "Informations",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                else if (File.Exists(path))
                {
                    var fi = new FileInfo(path);
                    MessageBox.Show(
                        $"Nom : {fi.Name}\n" +
                        $"Type : Fichier {fi.Extension}\n" +
                        $"Chemin : {fi.FullName}\n" +
                        $"Taille : {FormatSize(fi.Length)}\n" +
                        $"Modifié : {fi.LastWriteTime:dd/MM/yyyy HH:mm}",
                        "Informations",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            else
            {
                string entryName = item.Tag?.ToString();
                if (string.IsNullOrEmpty(entryName))
                    return;

                try
                {
                    using (var zip = ZipFile.OpenRead(_currentZip))
                    {
                        var entry = zip.GetEntry(entryName);
                        if (entry == null)
                        {
                            MessageBox.Show("Entrée introuvable dans l'archive.");
                            return;
                        }

                        MessageBox.Show(
                            $"Nom : {entry.FullName}\n" +
                            $"Type : Fichier dans archive\n" +
                            $"Taille (décompressée) : {FormatSize(entry.Length)}\n" +
                            $"Taille (compressée) : {FormatSize(entry.CompressedLength)}\n" +
                            $"Modifié : {entry.LastWriteTime.LocalDateTime:dd/MM/yyyy HH:mm}",
                            "Informations (archive)",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de la lecture de l'archive : " + ex.Message);
                }
            }
        }

        private void btnRepair_Click(object sender, EventArgs e)
        {
            if (_currentZip == null)
            {
                MessageBox.Show("Aucune archive ouverte.");
                return;
            }

            if (MessageBox.Show("Tenter de réparer cette archive ?\nUne copie sera reconstruite.",
                                "Réparer l'archive",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    _archiveManager.RepairArchive(_currentZip);
                    MessageBox.Show("Réparation terminée. L'archive a été reconstruite.");
                    LoadZip(_currentZip);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Échec de la réparation : " + ex.Message);
                }
            }
        }

        // ============================
        // ===== OUTILS UTILITAIRES ===
        // ============================

        private string FormatSize(long bytes)
        {
            if (bytes > 1024L * 1024 * 1024)
                return (bytes / (1024.0 * 1024 * 1024)).ToString("0.##") + " Go";
            if (bytes > 1024L * 1024)
                return (bytes / (1024.0 * 1024)).ToString("0.##") + " Mo";
            if (bytes > 1024L)
                return (bytes / 1024.0).ToString("0.##") + " Ko";

            return bytes + " o";
        }

        private string Prompt(string title, string message)
        {
            using (Form prompt = new Form())
            {
                prompt.Width = 400;
                prompt.Height = 150;
                prompt.Text = title;
                prompt.FormBorderStyle = FormBorderStyle.FixedDialog;
                prompt.StartPosition = FormStartPosition.CenterParent;
                prompt.MaximizeBox = false;
                prompt.MinimizeBox = false;

                Label textLabel = new Label() { Left = 10, Top = 10, Width = 360, Text = message };
                TextBox textBox = new TextBox() { Left = 10, Top = 40, Width = 360 };

                Button confirmation = new Button() { Text = "OK", Left = 210, Width = 75, Top = 70, DialogResult = DialogResult.OK };
                Button cancel = new Button() { Text = "Annuler", Left = 295, Width = 75, Top = 70, DialogResult = DialogResult.Cancel };

                prompt.Controls.Add(textLabel);
                prompt.Controls.Add(textBox);
                prompt.Controls.Add(confirmation);
                prompt.Controls.Add(cancel);

                prompt.AcceptButton = confirmation;
                prompt.CancelButton = cancel;

                return prompt.ShowDialog(this) == DialogResult.OK ? textBox.Text : null;
            }
        }

        private void ApplyTheme()
        {
            if (_darkTheme)
            {
                this.BackColor = Color.FromArgb(45, 45, 48);
                this.ForeColor = Color.White;

                listViewFiles.BackColor = Color.FromArgb(30, 30, 30);
                listViewFiles.ForeColor = Color.White;

                menuStrip1.BackColor = Color.FromArgb(45, 45, 48);
                menuStrip1.ForeColor = Color.White;

                toolStrip1.BackColor = Color.FromArgb(45, 45, 48);
                toolStrip1.ForeColor = Color.White;

                statusStrip1.BackColor = Color.FromArgb(45, 45, 48);
                statusStrip1.ForeColor = Color.White;
            }
            else
            {
                this.BackColor = SystemColors.Control;
                this.ForeColor = SystemColors.ControlText;

                listViewFiles.BackColor = Color.White;
                listViewFiles.ForeColor = Color.Black;

                menuStrip1.BackColor = SystemColors.Control;
                menuStrip1.ForeColor = SystemColors.ControlText;

                toolStrip1.BackColor = SystemColors.Control;
                toolStrip1.ForeColor = SystemColors.ControlText;

                statusStrip1.BackColor = SystemColors.Control;
                statusStrip1.ForeColor = SystemColors.ControlText;
            }
        }

        private void ApplyLanguage()
        {
            if (_language == "FR")
            {
                fichierToolStripMenuItem.Text = "Fichier";
                nouveauToolStripMenuItem.Text = "Nouveau";
                ouvrirToolStripMenuItem.Text = "Ouvrir";
                quitterToolStripMenuItem.Text = "Quitter";

                commandesToolStripMenuItem.Text = "Commandes";
                extraireToolStripMenuItem.Text = "Extraire";
                ajouterToolStripMenuItem.Text = "Ajouter";
                testerToolStripMenuItem.Text = "Tester";

                outilsToolStripMenuItem.Text = "Outils";
                reparerToolStripMenuItem.Text = "Réparer";
                convertirToolStripMenuItem.Text = "Convertir format";

                optionsToolStripMenuItem.Text = "Options";
                langueToolStripMenuItem.Text = "Langue";
                themeToolStripMenuItem.Text = "Thème";
                parametresToolStripMenuItem.Text = "Paramètres";

                aideToolStripMenuItem.Text = "Aide";
                aproposToolStripMenuItem.Text = "À propos";
                licenceToolStripMenuItem.Text = "Licence";

                btnAdd.Text = "➕ Ajouter";
                btnExtract.Text = "📤 Extraire";
                btnTest.Text = "Tester";
                btnDelete.Text = "🗑 Supprimer";
                btnSearch.Text = "🔍 Rechercher";
                btnInfo.Text = "ℹ Informations";
                btnRepair.Text = "🛠 Réparer";
                btnUp.Text = "⬆ Dossier parent";

                statusLabel.Text = "Prêt";
            }
            else
            {
                fichierToolStripMenuItem.Text = "File";
                nouveauToolStripMenuItem.Text = "New";
                ouvrirToolStripMenuItem.Text = "Open";
                quitterToolStripMenuItem.Text = "Exit";

                commandesToolStripMenuItem.Text = "Commands";
                extraireToolStripMenuItem.Text = "Extract";
                ajouterToolStripMenuItem.Text = "Add";
                testerToolStripMenuItem.Text = "Test";

                outilsToolStripMenuItem.Text = "Tools";
                reparerToolStripMenuItem.Text = "Repair";
                convertirToolStripMenuItem.Text = "Convert format";

                optionsToolStripMenuItem.Text = "Options";
                langueToolStripMenuItem.Text = "Language";
                themeToolStripMenuItem.Text = "Theme";
                parametresToolStripMenuItem.Text = "Settings";

                aideToolStripMenuItem.Text = "Help";
                aproposToolStripMenuItem.Text = "About";
                licenceToolStripMenuItem.Text = "License";

                btnAdd.Text = "➕ Add";
                btnExtract.Text = "📤 Extract";
                btnTest.Text = "Test";
                btnDelete.Text = "🗑 Delete";
                btnSearch.Text = "🔍 Search";
                btnInfo.Text = "ℹ Info";
                btnRepair.Text = "🛠 Repair";
                btnUp.Text = "⬆ Parent folder";

                statusLabel.Text = "Ready";
            }
        }
    }
}