﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;

namespace MiniWinRAR
{
    public class ArchiveManager
    {
        // Simple : liste des entrées (nom complet dans l'archive)
        public List<string> ListEntries(string archivePath)
        {
            var result = new List<string>();

            using (var zip = ZipFile.OpenRead(archivePath))
            {
                foreach (var e in zip.Entries)
                    result.Add(e.FullName);
            }

            return result;
        }

        // Créer une nouvelle archive (zip ou .keyce) avec une liste de chemins (fichiers ou dossiers)
        public void CreateArchive(string archivePath, IEnumerable<string> paths)
        {
            if (File.Exists(archivePath))
                File.Delete(archivePath);

            using (var zip = ZipFile.Open(archivePath, ZipArchiveMode.Create))
            {
                foreach (var path in paths)
                {
                    if (File.Exists(path))
                    {
                        string nameInArchive = Path.GetFileName(path);
                        zip.CreateEntryFromFile(path, nameInArchive, CompressionLevel.Optimal);
                    }
                    else if (Directory.Exists(path))
                    {
                        string baseInArchive = Path.GetFileName(path).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                        if (!string.IsNullOrEmpty(baseInArchive))
                            baseInArchive += "/";

                        AddDirectoryRecursive(zip, path, baseInArchive);
                    }
                }
            }
        }

        private void AddDirectoryRecursive(ZipArchive zip, string folderPath, string baseInArchive)
        {
            foreach (var file in Directory.GetFiles(folderPath))
            {
                string relativeName = baseInArchive + Path.GetFileName(file);
                zip.CreateEntryFromFile(file, relativeName, CompressionLevel.Optimal);
            }

            foreach (var dir in Directory.GetDirectories(folderPath))
            {
                string dirName = Path.GetFileName(dir);
                string newBase = baseInArchive + dirName + "/";
                AddDirectoryRecursive(zip, dir, newBase);
            }
        }

        // Ajouter des fichiers dans une archive existante
        public void AddFiles(string archivePath, IEnumerable<string> files)
        {
            using (var zip = ZipFile.Open(archivePath, ZipArchiveMode.Update))
            {
                foreach (var file in files)
                {
                    if (!File.Exists(file)) continue;

                    string name = Path.GetFileName(file);
                    zip.GetEntry(name)?.Delete(); // remplace si existe déjà
                    zip.CreateEntryFromFile(file, name, CompressionLevel.Optimal);
                }
            }
        }

        // Supprimer des entrées de l'archive
        public void RemoveEntries(string archivePath, IEnumerable<string> entryNames)
        {
            using (var zip = ZipFile.Open(archivePath, ZipArchiveMode.Update))
            {
                foreach (var name in entryNames)
                {
                    var entry = zip.GetEntry(name);
                    entry?.Delete();
                }
            }
        }

        // Extraire toute l'archive vers un dossier
        public void ExtractAll(string archivePath, string destination)
        {
            Directory.CreateDirectory(destination);
            ZipFile.ExtractToDirectory(archivePath, destination, overwriteFiles: true);
        }

        // Tester l'archive : si on peut tout lire sans exception → OK
        public bool TestArchive(string archivePath)
        {
            try
            {
                using (var zip = ZipFile.OpenRead(archivePath))
                {
                    byte[] buffer = new byte[1];

                    foreach (var entry in zip.Entries)
                    {
                        if (entry.Length == 0)
                            continue;

                        using var s = entry.Open();
                        s.Read(buffer, 0, 1);
                    }
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        // Réparer l'archive : recopier toutes les entrées dans une nouvelle archive
        public void RepairArchive(string archivePath)
        {
            string temp = archivePath + ".tmp";

            try
            {
                if (File.Exists(temp))
                    File.Delete(temp);

                using (var source = ZipFile.OpenRead(archivePath))
                using (var dest = ZipFile.Open(temp, ZipArchiveMode.Create))
                {
                    foreach (var entry in source.Entries)
                    {
                        var newEntry = dest.CreateEntry(entry.FullName, CompressionLevel.Optimal);
                        using (var sourceStream = entry.Open())
                        using (var destStream = newEntry.Open())
                        {
                            sourceStream.CopyTo(destStream);
                        }
                    }
                }

                File.Copy(temp, archivePath, overwrite: true);
                File.Delete(temp);
            }
            catch
            {
                if (File.Exists(temp))
                    File.Delete(temp);
                throw;
            }
        }
    }
}