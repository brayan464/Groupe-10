﻿using System;
using System.Windows.Forms;

namespace MiniWinRAR
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fichierToolStripMenuItem;
        private ToolStripMenuItem nouveauToolStripMenuItem;
        private ToolStripMenuItem ouvrirToolStripMenuItem;
        private ToolStripMenuItem quitterToolStripMenuItem;

        private ToolStripMenuItem commandesToolStripMenuItem;
        private ToolStripMenuItem extraireToolStripMenuItem;
        private ToolStripMenuItem ajouterToolStripMenuItem;
        private ToolStripMenuItem testerToolStripMenuItem;

        private ToolStripMenuItem outilsToolStripMenuItem;
        private ToolStripMenuItem reparerToolStripMenuItem;
        private ToolStripMenuItem convertirToolStripMenuItem;

        private ToolStripMenuItem optionsToolStripMenuItem;
        private ToolStripMenuItem langueToolStripMenuItem;
        private ToolStripMenuItem themeToolStripMenuItem;
        private ToolStripMenuItem parametresToolStripMenuItem;

        private ToolStripMenuItem aideToolStripMenuItem;
        private ToolStripMenuItem aproposToolStripMenuItem;
        private ToolStripMenuItem licenceToolStripMenuItem;

        private ToolStrip toolStrip1;
        private ToolStripButton btnUp;
        private ToolStripButton btnAdd;
        private ToolStripButton btnExtract;
        private ToolStripButton btnTest;
        private ToolStripButton btnDelete;
        private ToolStripButton btnSearch;
        private ToolStripButton btnInfo;
        private ToolStripButton btnRepair;

        private ListView listViewFiles;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel statusLabel;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            this.menuStrip1 = new MenuStrip();

            this.fichierToolStripMenuItem = new ToolStripMenuItem("Fichier");
            this.nouveauToolStripMenuItem = new ToolStripMenuItem("Nouveau");
            this.ouvrirToolStripMenuItem = new ToolStripMenuItem("Ouvrir");
            this.quitterToolStripMenuItem = new ToolStripMenuItem("Quitter");

            this.commandesToolStripMenuItem = new ToolStripMenuItem("Commandes");
            this.extraireToolStripMenuItem = new ToolStripMenuItem("Extraire");
            this.ajouterToolStripMenuItem = new ToolStripMenuItem("Ajouter");
            this.testerToolStripMenuItem = new ToolStripMenuItem("Tester");

            this.outilsToolStripMenuItem = new ToolStripMenuItem("Outils");
            this.reparerToolStripMenuItem = new ToolStripMenuItem("Réparer");
            this.convertirToolStripMenuItem = new ToolStripMenuItem("Convertir format");

            this.optionsToolStripMenuItem = new ToolStripMenuItem("Options");
            this.langueToolStripMenuItem = new ToolStripMenuItem("Langue");
            this.themeToolStripMenuItem = new ToolStripMenuItem("Thème");
            this.parametresToolStripMenuItem = new ToolStripMenuItem("Paramètres");

            this.aideToolStripMenuItem = new ToolStripMenuItem("Aide");
            this.aproposToolStripMenuItem = new ToolStripMenuItem("À propos");
            this.licenceToolStripMenuItem = new ToolStripMenuItem("Licence");

            this.toolStrip1 = new ToolStrip();
            this.btnUp = new ToolStripButton("⬆ Dossier parent");
            this.btnAdd = new ToolStripButton("➕ Ajouter");
            this.btnExtract = new ToolStripButton("📤 Extraire");
            this.btnTest = new ToolStripButton("Tester");
            this.btnDelete = new ToolStripButton("🗑 Supprimer");
            this.btnSearch = new ToolStripButton("🔍 Rechercher");
            this.btnInfo = new ToolStripButton("ℹ Informations");
            this.btnRepair = new ToolStripButton("🛠 Réparer");

            this.listViewFiles = new ListView();
            this.statusStrip1 = new StatusStrip();
            this.statusLabel = new ToolStripStatusLabel("Prêt");

            // ===== MENU =====
            this.menuStrip1.Items.AddRange(new ToolStripItem[]
            {
                this.fichierToolStripMenuItem,
                this.commandesToolStripMenuItem,
                this.outilsToolStripMenuItem,
                this.optionsToolStripMenuItem,
                this.aideToolStripMenuItem
            });

            this.fichierToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[]
            {
                this.nouveauToolStripMenuItem,
                this.ouvrirToolStripMenuItem,
                this.quitterToolStripMenuItem
            });

            this.commandesToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[]
            {
                this.extraireToolStripMenuItem,
                this.ajouterToolStripMenuItem,
                this.testerToolStripMenuItem
            });

            this.outilsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[]
            {
                this.reparerToolStripMenuItem,
                this.convertirToolStripMenuItem
            });

            this.optionsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[]
            {
                this.langueToolStripMenuItem,
                this.themeToolStripMenuItem,
                this.parametresToolStripMenuItem
            });

            this.aideToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[]
            {
                this.aproposToolStripMenuItem,
                this.licenceToolStripMenuItem
            });

            this.menuStrip1.Dock = DockStyle.Top;

            // ===== TOOLSTRIP =====
            this.toolStrip1.Items.AddRange(new ToolStripItem[]
            {
                this.btnUp,
                this.btnAdd,
                this.btnExtract,
                this.btnTest,
                this.btnDelete,
                this.btnSearch,
                this.btnInfo,
                this.btnRepair
            });
            this.toolStrip1.Dock = DockStyle.Top;

            // ===== LISTVIEW =====
            this.listViewFiles.View = View.Details;
            this.listViewFiles.FullRowSelect = true;
            this.listViewFiles.Dock = DockStyle.Fill;
            this.listViewFiles.Columns.Add("Nom", 260);
            this.listViewFiles.Columns.Add("Taille", 90);
            this.listViewFiles.Columns.Add("Type", 140);
            this.listViewFiles.Columns.Add("Modifié", 160);

            // ===== STATUS BAR =====
            this.statusStrip1.Items.Add(this.statusLabel);
            this.statusStrip1.Dock = DockStyle.Bottom;

            // ===== FORM =====
            this.Text = "Mini-WinRAR";
            this.Width = 900;
            this.Height = 600;
            this.StartPosition = FormStartPosition.CenterScreen;

            this.Controls.Add(this.listViewFiles);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.statusStrip1);

            this.MainMenuStrip = this.menuStrip1;
        }
    }
}