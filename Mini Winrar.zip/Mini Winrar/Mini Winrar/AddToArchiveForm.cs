﻿using System;
using System.Windows.Forms;

namespace MiniWinRAR
{
    public class AddToArchiveForm : Form
    {
        private TextBox txtName;
        private TextBox txtDestination;
        private ComboBox cmbFormat;
        private NumericUpDown numDictionary;
        private NumericUpDown numVolume;
        private TextBox txtPassword;
        private Button btnBrowse;
        private Button btnOk;
        private Button btnCancel;

        public string ArchiveName => txtName.Text.Trim();
        public string DestinationFolder => txtDestination.Text.Trim();
        public string SelectedExtension
            => (cmbFormat.SelectedItem?.ToString() ?? ".zip");
        public int DictionarySize => (int)numDictionary.Value;
        public long VolumeSize => (long)numVolume.Value;
        public string Password => txtPassword.Text; // pour l'instant pas utilisé dans la compression

        public AddToArchiveForm(string defaultName, string defaultFolder)
        {
            Text = "Ajouter à l'archive";
            Width = 420;
            Height = 320;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterParent;
            MaximizeBox = false;
            MinimizeBox = false;

            InitControls(defaultName, defaultFolder);
        }

        private void InitControls(string defaultName, string defaultFolder)
        {
            Label lblName = new Label { Text = "Nom de l'archive :", Left = 10, Top = 15, Width = 130 };
            txtName = new TextBox { Left = 150, Top = 12, Width = 230, Text = defaultName };

            Label lblDest = new Label { Text = "Emplacement :", Left = 10, Top = 50, Width = 130 };
            txtDestination = new TextBox { Left = 150, Top = 47, Width = 190, Text = defaultFolder };
            btnBrowse = new Button { Text = "...", Left = 345, Top = 45, Width = 35 };
            btnBrowse.Click += BtnBrowse_Click;

            Label lblFormat = new Label { Text = "Format :", Left = 10, Top = 85, Width = 130 };
            cmbFormat = new ComboBox { Left = 150, Top = 82, Width = 120, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbFormat.Items.Add(".zip");
            cmbFormat.Items.Add(".keyce");
            cmbFormat.SelectedIndex = 0;

            Label lblDict = new Label { Text = "Taille dictionnaire (Ko) :", Left = 10, Top = 120, Width = 130 };
            numDictionary = new NumericUpDown { Left = 150, Top = 117, Width = 80, Minimum = 1, Maximum = 1024, Value = 64 };

            Label lblVol = new Label { Text = "Fractionner (Mo) :", Left = 10, Top = 155, Width = 130 };
            numVolume = new NumericUpDown { Left = 150, Top = 152, Width = 80, Minimum = 0, Maximum = 10240, Value = 0 };
            // 0 = pas de fractionnement (non implémenté pour l’instant)

            Label lblPwd = new Label { Text = "Mot de passe :", Left = 10, Top = 190, Width = 130 };
            txtPassword = new TextBox { Left = 150, Top = 187, Width = 230, UseSystemPasswordChar = true };

            btnOk = new Button { Text = "OK", Left = 210, Top = 225, Width = 80 };
            btnCancel = new Button { Text = "Annuler", Left = 300, Top = 225, Width = 80 };

            btnOk.DialogResult = DialogResult.OK;
            btnCancel.DialogResult = DialogResult.Cancel;

            Controls.AddRange(new Control[]
            {
                lblName, txtName,
                lblDest, txtDestination, btnBrowse,
                lblFormat, cmbFormat,
                lblDict, numDictionary,
                lblVol, numVolume,
                lblPwd, txtPassword,
                btnOk, btnCancel
            });

            AcceptButton = btnOk;
            CancelButton = btnCancel;
        }

        private void BtnBrowse_Click(object sender, EventArgs e)
        {
            using var fbd = new FolderBrowserDialog();
            if (fbd.ShowDialog() == DialogResult.OK)
                txtDestination.Text = fbd.SelectedPath;
        }
    }
}