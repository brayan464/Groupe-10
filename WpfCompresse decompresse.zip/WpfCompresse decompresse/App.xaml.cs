﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace WpfCompresse_decompresse
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
